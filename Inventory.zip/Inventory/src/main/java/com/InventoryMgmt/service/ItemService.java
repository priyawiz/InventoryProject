package com.InventoryMgmt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.InventoryMgmt.model.Item;
import com.InventoryMgmt.repository.ItemRepository;

import java.util.List;
import java.util.Optional;


@Service
public class ItemService {
    private final ItemRepository itemRepository;

    @Autowired
    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }

    public Optional<Item> getItemById(Long itemId) {
        return itemRepository.findById(itemId);
    }

    public Item createItem(Item item) {
        if (item.getItemId() != null && itemRepository.existsById(item.getItemId())) {
            throw new IllegalArgumentException("Item with ID " + item.getItemId() + " already exists.");
        }
        return itemRepository.save(item);
    }

    public Optional<Item> updateItem(Long itemId, Item updatedItem) {
        Optional<Item> existingItemOptional = itemRepository.findById(itemId);
        if (existingItemOptional.isEmpty()) {
            throw new IllegalArgumentException("Item with ID " + itemId + " not found.");
        }

        Item existingItem = existingItemOptional.get();
        existingItem.setItemName(updatedItem.getItemName());
        existingItem.setItemEnteredByUser(updatedItem.getItemEnteredByUser());
        existingItem.setItemBuyingPrice(updatedItem.getItemBuyingPrice());
        existingItem.setItemSellingPrice(updatedItem.getItemSellingPrice());
        existingItem.setItemStatus(updatedItem.getItemStatus());

        return Optional.of(itemRepository.save(existingItem));
    }

    public void deleteItem(Long itemId) {
        if (!itemRepository.existsById(itemId)) {
            throw new IllegalArgumentException("Item with ID " + itemId + " not found.");
        }
        itemRepository.deleteById(itemId);
    }

    public void deleteAllItems() {
        itemRepository.deleteAll();
    }

    public Page<Item> searchItemsByStatusAndEnteredBy(String status, String enteredBy, int page, int pageSize, String sortBy) {
        Pageable pageable = PageRequest.of(page, pageSize);
        return itemRepository.findByItemStatusAndItemEnteredByUser(status, enteredBy, pageable);
    }
}

